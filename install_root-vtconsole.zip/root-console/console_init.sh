#!/bin/bash
sleep 30
sudo openvt -c 7 -s -f -l -w
sudo systemctl start mediacenter
exit
